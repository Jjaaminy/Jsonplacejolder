import logo from './logo.svg';
import './App.css';
import {useState} from "react";

//noch nicht fertig....
export default function App() {
    const [todo, setTodo] = useState([]);

    const get = () => {
        fetch('https://jsonplaceholder.typicode.com/todos')
            .then(response => response.json())
            .then(json => {
                console.log(json)
                setTodo(json)
            });
    };

    useEffect(() => {
            get();
        },
        []);




 }

  return (

    <div className="App">
        <h1>Todo</h1>
        <button onClick={get()}>fetch api</button>
              <ul className="list-group">
                  {todo.map(item) => (
                  <li key={item.userId},{item.id},{item.title}>
                  </li>
                      )}
              </ul>
          )}</p>

    </div>
  );
}


